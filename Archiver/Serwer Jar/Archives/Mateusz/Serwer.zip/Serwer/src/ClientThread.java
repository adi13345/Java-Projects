import java.io.*;
import java.net.Socket;
import java.net.SocketException;

/**
 * Watek serwera, tworzony dla kazdego klienta
 */
public class ClientThread implements Runnable {
    /**
     * Id klienta
     */
    private String client_id;
    /**
     * Gniazdo polaczenia z klientem
     */
    private Socket socket;

    /**
     * Konstruktor watku serwera, przypisanie gniazda do zmiennej
     * @param socket - gniazdo polaczeniowe
     * @param id - id klienta, ktory nawizal polaczenie
     */
    public ClientThread(Socket socket, String id) {
        this.socket = socket;
        this.client_id = id;
    }
    /**
     * Metoda oblsugujaca przymujaca, zdarzenia pomiedzy klientem i serwerem
     */
    @Override
    public void run() {
        boolean thread_flag = true;//flaga watku, odbieranie żądan klienta
        while (thread_flag) {//ZMIENIC NA FLAGE GLOBALNE
            try {
                if(socket!=null) {
                    //dane wejsciowe od klienta sa w postaci bitowej, trzeba je przekonwertowac na tekst
                    InputStream inputStream = socket.getInputStream();//strumien wejsciowy na gniezdzie, dane od klienta
                    BufferedReader bufferedreader = new BufferedReader(new InputStreamReader(inputStream));//czytanie żądań klienta
                    OutputStream outputstream = socket.getOutputStream();//dane wyjsciowe od serwera
                    PrintWriter printwriter = new PrintWriter(outputstream, true);//przypisanie do strumienia wyjsciowego tego,
                    String clientrequest = bufferedreader.readLine();//przypisanie zadania klienta do zmiennej typu string
                    if (clientrequest != null) {//sprawdzanie czy klient wyslal wiadomosc
                        System.out.println(ConsoleFrame.getTimeandDate() + "ŻĄDANIE OD KLIENTA " + client_id + ": " + clientrequest);//komunikat na konsole Intellij
                        ConsoleFrame.textarea_.append(ConsoleFrame.getTimeandDate() + "ŻĄDANIE OD KLIENTA " + client_id + ": " + clientrequest + "\n");//komunikat na konsole serwera
                        Main.saveLogs(ConsoleFrame.getTimeandDate() + "ŻĄDANIE " + client_id + ": " + clientrequest);//komunikat do logow
                        String servermessage = ServerAction.ServerResponse(clientrequest,client_id);//obsluga zadania klienta przez klase SERverResponse
                        if (servermessage.equals("State:<250> Client logout") && servermessage !=null) {//w przypadku zadania natychmiastowego zerwania polaczenia
                            System.out.println(ConsoleFrame.getTimeandDate() + "Użytkownik o ID: "+client_id+" został wylogowany");//komunikat na konsole Intellij
                            ConsoleFrame.textarea_.append(ConsoleFrame.getTimeandDate() + "Użytkownik o ID: "+client_id+" został wylogowany" + "\n");//komunikat o bledzie
                            Main.saveLogs(ConsoleFrame.getTimeandDate() + "Użytkownik o ID: "+client_id+" został wylogowany" );//komunikat do logow
                            Server.removeUserFromLoggedUserTable(client_id);//usuniecie usera z listy zalogowanych uzytkownikow
                            printwriter.println(servermessage);//wyslanei wiadomosci do klienta
                            printwriter.flush();//flush() wymusza "wypchniecie" z bufora wszystkich danych
                            thread_flag = false;//wylaczenie odbieranai żądań klienta
                            socket.close();//zamkniecie gniazda
                        }
                        else {
                            printwriter.println(servermessage);//utworzenie wiadomosci
                            printwriter.flush();//flush() wymusza "wypchniecie" z bufora wszystkich danych
                        }
                    }
                }
            } catch (SocketException err){
                System.out.println(ConsoleFrame.getTimeandDate() + "Zresetowano połączenie użytkownika o ID: "+client_id);//komunikat na konsole Intellij
                ConsoleFrame.textarea_.append(ConsoleFrame.getTimeandDate() + "Zresetowano połączenie użytkownika o ID: "+client_id+"\n");//komunikat o bledzie
                Main.saveLogs(ConsoleFrame.getTimeandDate() + "Zresetowano połączenie użytkownika o ID: "+client_id);//komunikat do logow
                Server.removeUserFromLoggedUserTable(client_id);//usuniecie usera z listy zalogowanych uzytkownikow
                thread_flag = false;//wylaczenie odbieranai żądań klienta
            }
            catch(NullPointerException er){
                System.out.println(ConsoleFrame.getTimeandDate() + "Użytkownik o ID: "+client_id+" został wylogowany");//komunikat na konsole Intellij
                ConsoleFrame.textarea_.append(ConsoleFrame.getTimeandDate() + "Użytkownik o ID: "+client_id+" został wylogowany" + "\n");//komunikat o bledzie
                Main.saveLogs(ConsoleFrame.getTimeandDate() + "Użytkownik o ID: "+client_id+" został wylogowany" );//komunikat do logow
                Server.removeUserFromLoggedUserTable(client_id);//usuniecie usera z listy zalogowanych uzytkownikow
                thread_flag = false;//wylaczenie odbieranai żądań klienta
            }
            catch (Exception e) {
                System.out.println(ConsoleFrame.getTimeandDate() + "Nastąpił niespodziewany błąd: " + e);//komunikat na konsole Intellij
                if(ConsoleFrame.textarea_!=null) {
                    ConsoleFrame.textarea_.append(ConsoleFrame.getTimeandDate() + "Nastąpił niespodziewany błąd: " + e + "\n");//komunikat o bledzie
                }
                Main.saveLogs(ConsoleFrame.getTimeandDate() + "Nastąpił niespodziewany błąd: " + e);//komunikat do logow
                Server.removeUserFromLoggedUserTable(client_id);//usuniecie usera z listy zalogowanych uzytkownikow
                thread_flag = false;//wylaczenie odbieranai żądań klienta
            }
        }
    }
}