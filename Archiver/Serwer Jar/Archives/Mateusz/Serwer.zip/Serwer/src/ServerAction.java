import java.io.File;

/**
 * Klasa odpowiedzialna za obsluge zadan klienta
 */
public class ServerAction {
    /**
     * Metoda oblsugujaca zadania od klienta
     * @param command zadanie klienta
     * @return odpowiedz serwera - wiadomosc jaka zostanie wyslana do klienta
     */
    public static String ServerResponse(String command, String id) {
        String ID = id;//id danego klienta
        String serverresponse = "NOTHING";//wiadomosc serwera
        String[] servercommand_bufor = command.split(":");//podzielenie żądania klienta na fragmenty

        switch (servercommand_bufor[0]) {//sprawdzenie jakiej kategorii jest żądanei klientow (bez sprawdzenia parametrow)
            case "LOGOUT":
                serverresponse = "State:<250> Client logout";//wiadomosc do klienta o wylogowywaniu
                break;
            case "SHOW_FILES":
                serverresponse = "OK:<205> "+getUserPath((ID));//wywolanie nizej zdefiniowanej metody - wyslanie do klienta nazw plikow, jakie posiada
                break;
        }
        return serverresponse;//odpowiedz serwera
    }

    /**
     * Metoda zwracaja liste plikow danego usera
     * @param ID - id usera, ktorego pliki maja zosta zwrocone
     * @return - pliki w danym folderze
     */
    private static String getUserPath(String ID) {
        String file_paths;
        try {
            String path = null;//sciezka do folderu usera
            for (int i = 0; i < Users.userstable.size(); i++) {//przeszukjemy cala tablice userow
                if (Users.userstable.get(i)[2].equals(ID)) {//sprawdzamy,ktorej sciezke odpowiada id klienta wyzylajacego żądanie
                    path = Users.userstable.get(i)[3];//przypisanie danej sciezki
                }
            }
            if(path != null) {//gdy udalo sie odnalezc danego usera i jego sicezke
                File file = new File(path);//sciezka do katalogu
                File[] filelist = file.listFiles();//lista wyszstkich plikow w danym folderze
                StringBuilder stringBuilder = new StringBuilder();//bufor na dane o plikach
                for (int j = 0; j < filelist.length; j++) {
                    stringBuilder.append(filelist[j].getName()+"%");
                }
                stringBuilder.delete(stringBuilder.length() - 1, stringBuilder.length());//usuwamy ostatni "%"
                file_paths = stringBuilder.toString();//konwersja na Stringa zbudowanego napisu
                return file_paths;//wiadomosc do usera
            }else{
                return "Error:<305> Cannot find specifed path";//gdy, nie ma okreslonego katalogu
            }
        }catch(StringIndexOutOfBoundsException er){//gdy w fodlerze nie ma plikow
            System.out.println(ConsoleFrame.getTimeandDate() + "Folder użytkownika o ID "+ID+" jest pusty");//komunikat na konsole Intellij
            ConsoleFrame.textarea_.append(ConsoleFrame.getTimeandDate() + "Folder użytkownika o ID "+ID+" jest pusty"+"\n");//komunikat o bledzie
            Main.saveLogs(ConsoleFrame.getTimeandDate() + "Folder użytkownika o ID "+ID+" jest pusty");//komunikat do logow
            return "Error:<306> Specified folder is empty";//gdy cos pojdzie nie tak
        }catch (Exception e){
            System.out.println(ConsoleFrame.getTimeandDate() + "Nastąpił nieoczekiany błąd podczas wczytywania plikow użytkownika o ID "+ID+": "+e);//komunikat na konsole Intellij
            ConsoleFrame.textarea_.append(ConsoleFrame.getTimeandDate() + "Nastąpił nieoczekiany błąd podczas wczytywania plikow użytkownika o ID "+ID+": "+e+"\n");//komunikat o bledzie
            Main.saveLogs(ConsoleFrame.getTimeandDate() + "Nastąpił nieoczekiany błąd podczas wczytywania plikow użytkownika o ID "+ID+": "+e);//komunikat do logow
            return "Fatal Error";//gdy cos pojdzie nie tak
        }
    }
}
